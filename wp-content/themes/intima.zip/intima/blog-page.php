<?php
/*
  Template Name: Blog
*/
?>

<?php
get_header();
get_current_page_template();
get_footer();
?>