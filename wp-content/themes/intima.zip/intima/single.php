<?php
get_header();
get_current_single_page();
get_footer();
?>