<?php

get_template_part('sections/section-footer');

?>